var in_plain_english = {
    "FriendsOfFondrenLibraryMembershipID2": "FoFL Member ID",
    "SchoolDepartmentOrProgram":"Department",
    //"SelectAffiliation": "Affiliation",
    "RiceNetID": "NetID",
    "Phone2": "Phone",
    "FullName": "Name",
    "Email2": "Email"
};

Date.prototype.formatMMDDYY = function(){
    return (this.getMonth() + 1) +
        "/" +  this.getDate() +
        "/" +  this.getYear();
};

var AirtablePlus = require('airtable-plus');
var airtable = new AirtablePlus(
    {apiKey: 'keyIk4M2lTl18JKBj',
    baseID: 'app9fOVxsIMeuvjDE',
    tableName: 'Registrants'});



exports.handler = async (event) => {
    // TODO implement
    //console.log(event.Records);
    var response = {};

    console.log(event.Records[0].Sns.Message);
    var cognitoPayload = event.Records[0].Sns.Message;
    console.log(typeof cognitoPayload);
    if(typeof cognitoPayload == "string"){
        cognitoPayload = JSON.parse(cognitoPayload);
    }
    //cognitoPayload = JSON.parse(cognitoPayload);
    //code to gather affiliation
    for(var aff_prop in cognitoPayload.RiceAffiliation){
        console.log(aff_prop);
        if (in_plain_english.hasOwnProperty(aff_prop) && cognitoPayload.RiceAffiliation[aff_prop] != null){

            response[in_plain_english[aff_prop]] = cognitoPayload.RiceAffiliation[aff_prop];
            console.log(response);

        }
    }

    //code to gather submission date
    //var registrant_date = new Date(cognitoPayload.Entry.Timestamp);
    var registrant_date = new Date();
    console.log("before date");
    response["Registration Date"] = registrant_date.formatMMDDYY();
    console.log(response);

    //code to gather contact info
    for(var contact_prop in cognitoPayload.ContactInfo){
        console.log(contact_prop);
        if (in_plain_english.hasOwnProperty(contact_prop) && cognitoPayload.ContactInfo[contact_prop] != null) {

            response[in_plain_english[contact_prop]] = cognitoPayload.ContactInfo[contact_prop];
            console.log(response);

        }
    }
    console.log(response);
    console.log("before returning await");
    return await airtable.create(response);


    // const response = {
    //     statusCode: 200,
    //     body: event.reqbody
    // };
    //return response;
};
