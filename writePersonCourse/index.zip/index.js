var in_plain_english = {
    "FriendsOfFondrenLibraryMembershipID2": "FoFL Member ID",
    "SchoolDepartmentOrProgram":"Department",
    "SelectAffiliation": "Affiliation",
    "RiceNetID": "NetID",
    "Phone2": "Phone",
    "FullName": "Name",
    "Email2": "Email"
};

Date.prototype.formatMMDDYY = function(){
    return (this.getMonth() + 1) +
        "/" +  this.getDate() +
        "/" +  this.getFullYear().substring(2);
};

var AirtablePlus = require('airtable-plus');
var airtable = new AirtablePlus(
    {apiKey: 'keyIk4M2lTl18JKBj',
        baseID: 'app9fOVxsIMeuvjDE',
        tableName: 'Registrants New'});

var AWS = require('aws-sdk');
var dynamodb = new AWS.DynamoDB({apiVersion: '2012-08-10'});

async function getShortForm(long_form_string){
    var return_string = "";
    let a = await dynamodb.getItem({"Key": {"formoption": {"S": long_form_string}}},
        function(err, data) {
            if (err) console.log(err, err.stack); // an error occurred
            else{
                console.log(data);
                return_string = data.Item.session["S"]; //the short form of the course
            }
        });
    return return_string;
}

exports.handler = async (event) => {
    // TODO implement
    //console.log(event.Records);
    var response = {};

    console.log(event.Records[0].Sns.Message);
    var cognitoPayload = event.Records[0].Sns.Message;
    console.log(typeof cognitoPayload);
    if(typeof cognitoPayload == "string"){
        cognitoPayload = JSON.parse(cognitoPayload);
    }
    //cognitoPayload = JSON.parse(cognitoPayload);

    //code to gather submission date
    //var registrant_date = new Date(cognitoPayload.Entry.Timestamp);
    var registrant_date = new Date();
    console.log("before date");
    response["Registration Date"] = registrant_date.formatMMDDYY();
    console.log(response);

    var name = cognitoPayload.ContactInfo.FullName;
    var email = cognitoPayload.ContactInfo.Email2;

    // to get courses
    var courseObject = cognitoPayload.GDCCourseSelection;
    for(var category in courseObject){
        if(typeof courseObject[category] == "string"){
            var payload = {};
            var long_name = courseObject[category];
            var dateShortCourse = new Date(long_name.split("|")[0]);
            var shortFormShortCourse = await getShortForm(long_name);

            //courseObject[category] is long form of course
            console.log(shortFormShortCourse);
            console.log("Finished async dynamo getItem");

            payload["Course"] = shortFormShortCourse + " " + dateShortCourse.formatMMDDYY();
            payload["Registrant"] = name;
            payload["Email"] = email;

            let resp = await airtable.create(payload); //may want to remove this
        }
        else if(typeof courseObject[category] == "object"){
            for(var long_name in courseObject[category]){
                var payload = {};
                var dateShortCourse = new Date(long_name.split("|")[0]);
                var shortFormShortCourse = await getShortForm(long_name);

                //courseObject[category] is long form of course
                console.log(shortFormShortCourse);
                console.log("Finished async dynamo getItem");

                payload["Course"] = shortFormShortCourse + " " + dateShortCourse.formatMMDDYY();
                payload["Registrant"] = name;
                payload["Email"] = email;

                let resp = await airtable.create(payload);
            }
        }
    }

    console.log(response);
    console.log("before returning await");
    //return await airtable.upsert('Name', response);
    return await airtable.create( response);


    // const response = {
    //     statusCode: 200,
    //     body: event.reqbody
    // };
    //return response;
};
